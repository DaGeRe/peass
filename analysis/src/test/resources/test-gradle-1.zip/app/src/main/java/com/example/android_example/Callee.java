package com.example.android_example;

public class Callee {
    protected int testMethod(){
        int tmp = 2;
        for (int i = 0; i < 10000000; i++) {
            tmp += i^i;
        }
        return tmp;
    }
}
